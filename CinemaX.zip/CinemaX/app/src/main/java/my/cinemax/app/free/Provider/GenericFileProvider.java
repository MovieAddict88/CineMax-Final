package my.cinemax.app.free.Provider;


import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {

}
