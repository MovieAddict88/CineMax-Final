package my.cinemax.app.free.entity;

public class Actress
{

    public static final String actress  = new String(new byte[]{104,116,116,112,115,58,47,47,102,97,103,109,109,109,117,46,120,121,122,47,97,112,105,47});


}

