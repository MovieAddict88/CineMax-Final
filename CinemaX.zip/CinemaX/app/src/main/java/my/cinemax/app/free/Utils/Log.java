package my.cinemax.app.free.Utils;

/**
 * Created by Tamim on 21/3/17.
 */
public class Log {
    public static void log(String msg) {
        android.util.Log.d("Nzm",""+msg);
    }
}
