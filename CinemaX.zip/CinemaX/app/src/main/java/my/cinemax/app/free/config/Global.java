package my.cinemax.app.free.config;

/**
 * Created by Tamim on 28/09/2017.
 */



public class Global {
	
	//public static final String API_URL = "https://tubungan.cf/api/";// new String(new byte[]{34,104,116,116,112,115,58,47,47,116,117,98,117,110,103,97,110,46,99,102,47,97,112,105,47,34});
	
	
	
    // Change this to your GitHub Raw URL where you upload free_movie_api.json
    public static final String API_URL = "https://raw.githubusercontent.com/MovieAddict88/movie-api/main/free_movie_api.json";
    public static final String ADS_API_URL = "https://raw.githubusercontent.com/MovieAddict88/movie-api/main/ads_config.json";
    
    // Original encoded URL (commented out)
    // public static final String API_URL = new String(new byte[]{104,116,116,112,115,58,47,47,102,97,99,101,98,111,111,107,46,99,111,109,47,102,97,103,109,109,109,117,99,111,100,101,115,101,99,116,111,114});
    public static final String SECURE_KEY = "4F5A9C3D9A86FA54EACEDDD635185";

    public static final String Youtube_Key = "AIzaSyAephi0fVTEBXgphX7Z_WVSW8iPusDibtg"; // get it from this link  https://console.developers.google.com/apis/credentials

    public static final String ITEM_PURCHASE_CODE = "d506abfd-9fe2-4b71-b979-feff21bcad13";



    public static final String SUBSCRIPTION_ID = "my.cinemax.app.free.subs";

}



