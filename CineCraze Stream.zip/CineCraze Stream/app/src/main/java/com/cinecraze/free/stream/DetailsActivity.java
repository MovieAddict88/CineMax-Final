package com.cinecraze.free.stream;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.Button;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cinecraze.free.stream.models.Entry;
import com.cinecraze.free.stream.models.Season;
import com.cinecraze.free.stream.models.Episode;
import com.cinecraze.free.stream.models.Server;
import com.cinecraze.free.stream.utils.VideoServerUtils;
import com.cinecraze.free.stream.player.CustomPlayerFragment;
import com.google.gson.Gson;

import java.util.List;

public class DetailsActivity extends AppCompatActivity {

    private static final String TAG = "DetailsActivity";

    // UI Components
    private TextView title;
    private TextView description;
    private RecyclerView relatedContentRecyclerView;
    
    // Server selector components
    private LinearLayout serverSelectorContainer;
    private Button serverSpinnerButton;
    private TextView serverInfoText;
    
    // TV Series components
    private LinearLayout seasonSelectorContainer;
    private Button seasonSpinnerButton;
    private TextView seasonInfoText;
    private LinearLayout episodeSelectorContainer;
    private RecyclerView episodeRecyclerView;
    
    // Enhanced video source selection
    private int currentServerIndex = 0;
    private int currentSeasonIndex = 0;
    private SmartServerSpinner smartServerSpinner;
    private boolean isInFullscreen = false;
    
    // CinemaX Player Fragment
    private CustomPlayerFragment customPlayerFragment;
    
    // Data
    private Entry currentEntry;
    private Season currentSeason;
    private Episode currentEpisode;
    private List<Server> currentServers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        
        try {
            initializeViews();
            setupData();
            setupVideoPlayer();
        } catch (Exception e) {
            Log.e(TAG, "Error in onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading content: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initializeViews() {
        title = findViewById(R.id.title);
        description = findViewById(R.id.description);
        relatedContentRecyclerView = findViewById(R.id.related_content_recycler_view);
        
        // Initialize server selector components
        serverSelectorContainer = findViewById(R.id.server_selector_container);
        serverSpinnerButton = findViewById(R.id.server_spinner_button);
        serverInfoText = findViewById(R.id.server_info_text);
        
        // Initialize TV Series components
        seasonSelectorContainer = findViewById(R.id.season_selector_container);
        seasonSpinnerButton = findViewById(R.id.season_spinner_button);
        seasonInfoText = findViewById(R.id.season_info_text);
        episodeSelectorContainer = findViewById(R.id.episode_selector_container);
        episodeRecyclerView = findViewById(R.id.episode_recycler_view);
        
        // Setup click listeners
        serverSpinnerButton.setOnClickListener(v -> showServerSpinner());
        seasonSpinnerButton.setOnClickListener(v -> showSeasonSpinner());
    }

    private void setupData() {
        currentEntry = getEntryFromIntent();
        if (currentEntry != null) {
            title.setText(currentEntry.getTitle());
            description.setText(currentEntry.getDescription());
            
            // Setup server selector
            setupServerSelector();
            
            // Setup TV Series components if it's a TV series
            if ("TV Series".equalsIgnoreCase(currentEntry.getMainCategory()) || 
                "TV".equalsIgnoreCase(currentEntry.getMainCategory())) {
                setupTVSeriesComponents();
            } else {
                // Hide season selector for movies
                seasonSelectorContainer.setVisibility(View.GONE);
                episodeSelectorContainer.setVisibility(View.GONE);
            }
        } else {
            Log.e(TAG, "No entry data received");
            Toast.makeText(this, "No content data available", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void setupServerSelector() {
        currentServers = getCurrentServers();
        if (currentServers != null && !currentServers.isEmpty()) {
            serverSelectorContainer.setVisibility(View.VISIBLE);
            updateServerButtonText();
            updateServerInfo();
        } else {
            serverSelectorContainer.setVisibility(View.GONE);
        }
    }

    private void setupTVSeriesComponents() {
        if (currentEntry.getSeasons() != null && !currentEntry.getSeasons().isEmpty()) {
            seasonSelectorContainer.setVisibility(View.VISIBLE);
            episodeSelectorContainer.setVisibility(View.VISIBLE);
            
            // Setup season adapter
            setupSeasonAdapter();
            
            // Select first season by default
            if (!currentEntry.getSeasons().isEmpty()) {
                currentSeason = currentEntry.getSeasons().get(0);
                updateSeasonButtonText();
                setupEpisodeAdapter();
            }
        } else {
            seasonSelectorContainer.setVisibility(View.GONE);
            episodeSelectorContainer.setVisibility(View.GONE);
        }
    }

    private void setupSeasonAdapter() {
        // For now, we'll use a simple spinner approach
        // You can enhance this with a custom adapter if needed
        updateSeasonButtonText();
    }

    private void setupEpisodeAdapter() {
        if (currentSeason != null && currentSeason.getEpisodes() != null && !currentSeason.getEpisodes().isEmpty()) {
            episodeRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
            EpisodeAdapter episodeAdapter = new EpisodeAdapter(this, currentSeason.getEpisodes(), new EpisodeAdapter.OnEpisodeClickListener() {
                @Override
                public void onEpisodeClick(Episode episode, int position) {
                    currentEpisode = episode;
                    currentServerIndex = 0; // Reset server index for new episode
                    updateServerSelector();
                    setupVideoPlayer();
                }
            });
            episodeRecyclerView.setAdapter(episodeAdapter);
            
            // Select first episode by default
            currentEpisode = currentSeason.getEpisodes().get(0);
        }
    }

    private void showServerSpinner() {
        if (currentServers != null && currentServers.size() > 1) {
            smartServerSpinner = new SmartServerSpinner(this, currentServers, currentServerIndex);
            smartServerSpinner.setOnServerSelectedListener(new SmartServerSpinner.OnServerSelectedListener() {
                @Override
                public void onServerSelected(Server server, int position) {
                    currentServerIndex = position;
                    updateServerButtonText();
                    updateServerInfo();
                    setupVideoPlayer();
                }
            });
            smartServerSpinner.show(serverSpinnerButton);
        } else {
            Toast.makeText(this, "Only one server available", Toast.LENGTH_SHORT).show();
        }
    }

    private void showSeasonSpinner() {
        if (currentEntry.getSeasons() != null && currentEntry.getSeasons().size() > 1) {
            String[] seasonNames = new String[currentEntry.getSeasons().size()];
            for (int i = 0; i < currentEntry.getSeasons().size(); i++) {
                seasonNames[i] = "Season " + currentEntry.getSeasons().get(i).getSeason();
            }

            androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
            builder.setTitle("Select Season");
            builder.setSingleChoiceItems(seasonNames, currentSeasonIndex, (dialog, which) -> {
                currentSeasonIndex = which;
                currentSeason = currentEntry.getSeasons().get(which);
                currentEpisode = null; // Reset episode
                currentServerIndex = 0; // Reset server index
                updateSeasonButtonText();
                updateSeasonInfo();
                setupEpisodeAdapter();
                updateServerSelector();
                setupVideoPlayer();
                dialog.dismiss();
            });
            builder.show();
        } else {
            Toast.makeText(this, "Only one season available", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateServerButtonText() {
        if (currentServers != null && currentServers.size() > currentServerIndex) {
            Server server = currentServers.get(currentServerIndex);
            String serverType = VideoServerUtils.getServerType(server.getUrl());
            serverSpinnerButton.setText(serverType);
        }
    }

    private void updateServerInfo() {
        if (currentServers != null) {
            int totalServers = currentServers.size();
            int embedCount = 0;
            int directCount = 0;
            
            for (Server server : currentServers) {
                if (VideoServerUtils.isEmbeddedVideoUrl(server.getUrl())) {
                    embedCount++;
                } else {
                    directCount++;
                }
            }
            
            StringBuilder info = new StringBuilder();
            if (directCount > 0) info.append(directCount).append("D");
            if (embedCount > 0) {
                if (info.length() > 0) info.append("/");
                info.append(embedCount).append("E");
            }
            
            serverInfoText.setText(info.toString());
        }
    }

    private void updateSeasonButtonText() {
        if (currentSeason != null) {
            seasonSpinnerButton.setText("Season " + currentSeason.getSeason());
        }
    }

    private void updateSeasonInfo() {
        if (currentSeason != null && currentSeason.getEpisodes() != null) {
            seasonInfoText.setText(currentSeason.getEpisodes().size() + " episodes");
        }
    }

    private void updateServerSelector() {
        currentServers = getCurrentServers();
        if (currentServers != null && !currentServers.isEmpty()) {
            serverSelectorContainer.setVisibility(View.VISIBLE);
            updateServerButtonText();
            updateServerInfo();
        } else {
            serverSelectorContainer.setVisibility(View.GONE);
        }
    }

    private void setupVideoPlayer() {
        String videoUrl = getCurrentVideoUrl();
        
        if (videoUrl != null && !videoUrl.isEmpty()) {
            try {
                // Use the enhanced CustomPlayerFragment that handles both embedded and direct videos
                customPlayerFragment = CustomPlayerFragment.newInstance(
                    videoUrl,
                    false, // isLive
                    VideoServerUtils.getVideoType(videoUrl),
                    currentEntry != null ? currentEntry.getTitle() : "Video",
                    currentEntry != null ? currentEntry.getDescription() : "",
                    currentEntry != null ? currentEntry.getImageUrl() : "",
                    currentEntry != null ? currentEntry.getId() : 0,
                    "movie" // or "tv" based on content type
                );
                
                // Add fragment to container
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                transaction.replace(R.id.player_container, customPlayerFragment);
                transaction.commit();
                
            } catch (Exception e) {
                Log.e(TAG, "Error setting up video player: " + e.getMessage(), e);
                Toast.makeText(this, "Error setting up video player", Toast.LENGTH_LONG).show();
            }
        } else {
            Log.w(TAG, "No video URL available");
            Toast.makeText(this, "No video URL available", Toast.LENGTH_SHORT).show();
        }
    }

    private String getCurrentVideoUrl() {
        if (currentServers != null && currentServers.size() > currentServerIndex) {
            String url = currentServers.get(currentServerIndex).getUrl();
            return VideoServerUtils.enhanceVideoUrl(url);
        }
        return null;
    }

    private List<Server> getCurrentServers() {
        // For TV series, get servers from current episode
        if (currentEpisode != null && currentEpisode.getServers() != null && !currentEpisode.getServers().isEmpty()) {
            return currentEpisode.getServers();
        }
        // For movies, get servers from current entry
        if (currentEntry != null) {
            return currentEntry.getServers();
        }
        return null;
    }

    private Entry getEntryFromIntent() {
        try {
            String entryJson = getIntent().getStringExtra("entry");
            if (entryJson != null && !entryJson.isEmpty()) {
                Gson gson = new Gson();
                return gson.fromJson(entryJson, Entry.class);
            }
            
            Log.e(TAG, "No entry data found in intent");
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Error parsing entry from intent: " + e.getMessage(), e);
            return null;
        }
    }

    // Static method to start DetailsActivity
    public static void start(android.content.Context context, Entry entry) {
        try {
            android.content.Intent intent = new android.content.Intent(context, DetailsActivity.class);
            Gson gson = new Gson();
            intent.putExtra("entry", gson.toJson(entry));
            context.startActivity(intent);
        } catch (Exception e) {
            Log.e("DetailsActivity", "Error starting DetailsActivity: " + e.getMessage(), e);
            Toast.makeText(context, "Error opening content details", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Fragment handles its own lifecycle
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Fragment handles its own lifecycle
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Fragment handles its own cleanup
    }
}
